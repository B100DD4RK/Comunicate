package billapp.logic;

/**
 *
 * @author jf
 */
public class Product {
    private long idProduct;
}
